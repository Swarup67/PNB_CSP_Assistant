import { CustomerApplication, NotificationRecord } from './types';

export const MOCK_APPLICATIONS: CustomerApplication[] = [
  {
    id: 'APP-8842',
    name: 'Suresh Kumar',
    type: 'KYC Update',
    mobile: '+91 98765 43210',
    email: 'suresh.k@example.com',
    address: '123, MG Road, Bangalore, Karnataka',
    aadhaar: '5421-8890-1234',
    pan: 'ABCDE1234F',
    status: 'Under Review',
    date: '2026-05-01',
    documents: [
      { id: 'D1', name: 'Aadhaar_Suresh.pdf', type: 'PDF', url: '#', date: '2026-05-01' },
      { id: 'D2', name: 'PAN_Suresh.png', type: 'Image', url: '#', date: '2026-05-01' }
    ],
    notes: 'Awaiting signature verification.'
  },
  {
    id: 'APP-8843',
    name: 'Priya Sharma',
    type: 'Account KYC Submit',
    mobile: '+91 99887 76655',
    email: 'priya.s@example.com',
    address: '45, Huda City Centre, Gurgaon, Haryana',
    aadhaar: '8872-1109-5678',
    pan: 'FGHIJ5678K',
    status: 'Approved',
    date: '2026-05-03',
    documents: [
      { id: 'D3', name: 'Identity_Priya.pdf', type: 'PDF', url: '#', date: '2026-05-03' }
    ]
  },
  {
    id: 'APP-8844',
    name: 'Rohan Mehta',
    type: 'Change Personal Info',
    mobile: '+91 97766 55443',
    email: 'rohan.m@example.com',
    address: 'Flat 202, Regency Apartments, Mumbai',
    aadhaar: '9088-2231-9012',
    pan: 'KLMNO9012P',
    status: 'Processing',
    date: '2026-05-05',
    documents: [
      { id: 'D4', name: 'Address_Proof.pdf', type: 'PDF', url: '#', date: '2026-05-05' }
    ]
  },
  {
    id: 'APP-8845',
    name: 'Amit Singh',
    type: 'KYC Update',
    mobile: '+91 91122 33445',
    email: 'amit.s@example.com',
    address: 'Sector 15, Chandigarh',
    aadhaar: '7762-1100-3456',
    pan: 'PQRST3456L',
    status: 'Submitted',
    date: '2026-05-07',
    documents: []
  },
  {
    id: 'APP-8846',
    name: 'Deepa Verma',
    type: 'Account KYC Submit',
    mobile: '+91 95544 33221',
    email: 'deepa.v@example.com',
    address: 'Aliganj, Lucknow, UP',
    aadhaar: '4452-9908-7890',
    pan: 'UVWSX7890M',
    status: 'Rejected',
    date: '2026-05-04',
    notes: 'Document clarity is poor. Resubmission requested.',
    documents: []
  }
];

export const MOCK_NOTIFICATIONS: NotificationRecord[] = [
  { id: 'N1', type: 'SMS', message: 'Your KYC request APP-8843 has been approved.', customerName: 'Priya Sharma', time: '10:30 AM', status: 'Delivered' },
  { id: 'N2', type: 'Email', message: 'Welcome to PNB Assistant. Please complete your registration.', customerName: 'Amit Singh', time: '09:15 AM', status: 'Sent' },
  { id: 'N3', type: 'System', message: 'New application received from Rohan Mehta.', customerName: 'Rohan Mehta', time: 'Yesterday', status: 'Delivered' }
];

export const CHART_DATA = [
  { name: 'Mon', requests: 12, approved: 8 },
  { name: 'Tue', requests: 19, approved: 15 },
  { name: 'Wed', requests: 15, approved: 12 },
  { name: 'Thu', requests: 22, approved: 18 },
  { name: 'Fri', requests: 30, approved: 25 },
  { name: 'Sat', requests: 10, approved: 7 },
  { name: 'Sun', requests: 8, approved: 5 },
];
