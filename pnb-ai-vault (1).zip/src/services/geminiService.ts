import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY as string });

export interface ExtractedData {
  name?: string;
  mobile?: string;
  aadhaar?: string;
  pan?: string;
  address?: string;
  documentType: 'KYC Update' | 'Account KYC Submit' | 'Info Update' | 'Other';
}

export async function extractDataFromDocument(base64Data: string, mimeType: string): Promise<ExtractedData> {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: [
        {
          parts: [
            {
              inlineData: {
                data: base64Data,
                mimeType: mimeType,
              },
            },
            {
              text: "Extract information from this bank document (PDF or Image), KYC form, or ID card. Focus on Name, Aadhaar Number, PAN Number, Mobile Number, and Address. Also identify the type of transaction or document specifically as one of: 'KYC Update', 'Account KYC Submit', or 'Info Update' based on the content. For PDFs, scan all relevant pages for this data. Return 'Other' if the document type is not clear.",
            },
          ],
        },
      ],
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            name: { type: Type.STRING },
            mobile: { type: Type.STRING },
            aadhaar: { type: Type.STRING },
            pan: { type: Type.STRING },
            address: { type: Type.STRING },
            documentType: { 
              type: Type.STRING, 
              enum: ['KYC Update', 'Account KYC Submit', 'Info Update', 'Other'] 
            },
          },
          required: ["documentType"],
        },
      },
    });

    const result = JSON.parse(response.text || '{}');
    return result;
  } catch (error) {
    console.error("Error extracting data from document:", error);
    throw error;
  }
}
