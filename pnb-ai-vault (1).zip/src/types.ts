export type ApplicationStatus = 'Submitted' | 'Under Review' | 'Processing' | 'Approved' | 'Rejected' | 'Completed';

export interface CustomerApplication {
  id: string;
  name: string;
  type: string;
  mobile: string;
  email: string;
  address: string;
  aadhaar: string;
  pan: string;
  photoUrl?: string;
  status: ApplicationStatus;
  date: string;
  documents: DocumentRecord[];
  notes?: string;
  updatedAt?: any; // Firestore Timestamp
}

export interface DocumentRecord {
  id: string;
  name: string;
  type: string;
  url: string;
  date: string;
}

export interface NotificationRecord {
  id: string;
  type: 'SMS' | 'Email' | 'System';
  message: string;
  customerName: string;
  time: string;
  status: 'Delivered' | 'Sent' | 'Failed';
}
