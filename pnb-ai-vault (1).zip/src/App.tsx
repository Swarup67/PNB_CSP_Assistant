import React, { useState, useMemo, useEffect } from 'react';
import { 
  Shield, 
  UserRound, 
  FileText, 
  Search, 
  LayoutDashboard, 
  Users, 
  Bell, 
  Settings, 
  LogOut, 
  ChevronRight, 
  CheckCircle2, 
  Clock, 
  XCircle, 
  Filter, 
  Plus, 
  Scan, 
  Mail, 
  MessageSquare,
  ArrowRight,
  Menu,
  X,
  CreditCard,
  Building2,
  Lock,
  Eye,
  FileCheck,
  RefreshCw,
  MoreVertical,
  LogIn,
  Download,
  Camera,
  Image as ImageIcon,
  Check,
  AlertCircle,
  Fingerprint,
  ShieldCheck,
  Activity,
  ChevronDown,
  Info,
  Phone,
  MessageCircle
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { cn, fileToBase64 } from './lib/utils';
import { ApplicationStatus, CustomerApplication } from './types';
import { MOCK_APPLICATIONS, MOCK_NOTIFICATIONS, CHART_DATA } from './data';
import { auth, googleProvider, signInWithPopup, signOut, onAuthStateChanged, db, browserPopupRedirectResolver } from './lib/firebase';
import { collection, query, onSnapshot, orderBy, doc, updateDoc, Timestamp, addDoc } from 'firebase/firestore';
import { extractDataFromDocument, ExtractedData } from './services/geminiService';

const ALLOWED_ADMINS = [
  'jakirhossainobc786@gmail.com',
  'swarup2208@gmail.com',
  'anowara1532@gmail.com',
  'swaruphossain701385124899@gmail.com'
];

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  }
  const serializedError = JSON.stringify(errInfo, null, 2);
  console.error('Firestore Error Detailed: ', serializedError);
  throw new Error(serializedError);
}

// --- Components ---

const Badge = ({ children, variant = 'default' }: { children: React.ReactNode, variant?: 'default' | 'success' | 'warning' | 'error' | 'info' }) => {
  const styles = {
    default: 'bg-gray-100 text-gray-700',
    success: 'bg-green-100 text-green-700',
    warning: 'bg-yellow-100 text-yellow-700',
    error: 'bg-red-100 text-red-700',
    info: 'bg-blue-100 text-blue-700',
  };
  return (
    <span className={cn('px-2.5 py-0.5 rounded-full text-xs font-medium', styles[variant])}>
      {children}
    </span>
  );
};

// --- Page: Service Workflow ---
// --- Page: Service Workflow ---
const ScanVaultModal = ({ 
  isOpen, 
  onClose, 
  customers, 
  onAddDocument, 
  onCreateCustomer,
  showToast,
  initialType
}: { 
  isOpen: boolean, 
  onClose: () => void, 
  customers: CustomerApplication[],
  onAddDocument: (customerId: string, file: File, extracted?: ExtractedData) => Promise<void>,
  onCreateCustomer: (name: string, mobile: string, aadhaar: string, extra?: Partial<ExtractedData>, photoUrl?: string) => Promise<string>,
  showToast: (msg: string) => void,
  initialType?: string
}) => {
  const [isNewCust, setIsNewCust] = useState(true);
  const [selectedCustId, setSelectedCustId] = useState<string>('');
  const [newName, setNewName] = useState('');
  const [newMobile, setNewMobile] = useState('');
  const [newAadhaar, setNewAadhaar] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [reviewData, setReviewData] = useState<ExtractedData | null>(null);
  const [pendingFile, setPendingFile] = useState<File | null>(null);

  useEffect(() => {
    if (isOpen) {
      setIsNewCust(true);
      setReviewData(null);
      setPendingFile(null);
    }
  }, [isOpen]);

  const handleFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsProcessing(true);
    setPendingFile(file);
    try {
      const base64 = await fileToBase64(file);
      const extracted = await extractDataFromDocument(base64, file.type);
      // If we had an initial type, but AI found another one, we might want to prioritize AI or initial.
      // Usually AI finding is better.
      setReviewData(extracted);
    } catch (error) {
      console.error("AI Extraction failed:", error);
      showToast("AI extraction failed. Please fill manually.");
      setReviewData({
        documentType: (initialType as any) || 'Other',
        name: newName,
        mobile: newMobile,
        aadhaar: newAadhaar
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const handleConfirm = async () => {
    if (!pendingFile || !reviewData) return;

    const fileUrl = URL.createObjectURL(pendingFile);
    let finalId = selectedCustId;
    if (isNewCust || !selectedCustId) {
      finalId = await onCreateCustomer(
        reviewData.name || newName || 'Extracted Name', 
        reviewData.mobile || newMobile || 'Extracted Mobile', 
        reviewData.aadhaar || newAadhaar || '',
        reviewData,
        fileUrl
      );
    }

    await onAddDocument(finalId, pendingFile, reviewData);
    onClose();
    // Reset
    setSelectedCustId('');
    setIsNewCust(false);
    setNewName('');
    setNewMobile('');
    setNewAadhaar('');
    setReviewData(null);
    setPendingFile(null);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center p-6 bg-black/90 backdrop-blur-md">
          <motion.div 
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            className="bg-pnb-dark w-full max-w-xl rounded-[2.5rem] border border-pnb-gold/20 p-8 shadow-2xl relative overflow-hidden"
          >
            <div className="absolute top-0 right-0 p-8 opacity-5">
              <Scan size={120} className="text-pnb-gold" />
            </div>
            
            <button onClick={onClose} className="absolute top-6 right-6 text-white/30 hover:text-white transition-colors cursor-pointer z-50">
              <X size={20} />
            </button>

            <h3 className="text-2xl font-bold text-pnb-gold mb-1 uppercase tracking-wider">Scan & <span className="text-white italic lowercase">Vault</span></h3>
            <p className="text-[10px] text-white/30 mb-8 uppercase tracking-[0.3em] font-bold">Secure Digital Asset Archival</p>

            {isProcessing ? (
              <div className="py-20 flex flex-col items-center">
                <RefreshCw className="animate-spin text-pnb-gold mb-6" size={48} />
                <p className="text-pnb-gold font-bold animate-pulse uppercase tracking-[0.4em] text-[10px]">AI OCR Analysis in Progress...</p>
                <p className="text-white/20 text-[10px] mt-2">Processing Document & Extracting Data...</p>
              </div>
            ) : reviewData ? (
              <div className="space-y-6">
                <div className="bg-pnb-maroon/20 border border-pnb-gold/20 rounded-2xl p-6 relative overflow-hidden">
                   <div className="absolute top-4 right-4 bg-pnb-gold text-pnb-maroon text-[8px] font-bold px-2 py-1 rounded uppercase tracking-widest">
                     Verified OCR Result
                   </div>
                   <h4 className="text-xs font-bold text-pnb-gold uppercase tracking-widest mb-4 flex items-center gap-2">
                     <FileCheck size={14} /> Extraction Result: {reviewData.documentType}
                   </h4>
                   <div className="grid grid-cols-2 gap-4">
                     {[
                       { label: 'Name', value: reviewData.name },
                       { label: 'Mobile', value: reviewData.mobile },
                       { label: 'Aadhaar', value: reviewData.aadhaar },
                       { label: 'PAN', value: reviewData.pan },
                       { label: 'Address', value: reviewData.address, full: true }
                     ].map((item, idx) => item.value ? (
                       <div key={idx} className={item.full ? 'col-span-2' : ''}>
                         <p className="text-[8px] font-bold text-white/30 uppercase tracking-widest mb-1">{item.label}</p>
                         <p className="text-xs font-bold text-white leading-tight font-mono">{item.value}</p>
                       </div>
                     ) : null)}
                   </div>
                </div>

                <div className="flex gap-4">
                  <button 
                    onClick={() => setReviewData(null)}
                    className="flex-1 py-4 bg-white/5 text-white/60 rounded-xl font-bold uppercase tracking-widest text-[10px] border border-white/10 hover:bg-white/10 transition-all cursor-pointer"
                  >
                    Rescan
                  </button>
                  <button 
                    onClick={handleConfirm}
                    className="flex-1 py-4 bg-pnb-gold text-pnb-maroon rounded-xl font-bold uppercase tracking-widest text-[10px] shadow-xl shadow-pnb-gold/20 hover:scale-[1.02] active:scale-[0.98] transition-all cursor-pointer"
                  >
                    Confirm & Create Card
                  </button>
                </div>
              </div>
            ) : (
              <div className="space-y-6">
                <div>
                  <label className="text-[10px] font-bold text-white/30 uppercase tracking-widest mb-3 block">Target Identity</label>
                  <div className="flex gap-4 mb-4">
                    <button 
                      onClick={() => setIsNewCust(false)}
                      className={cn(
                        "flex-1 py-3 rounded-xl border text-[10px] font-bold uppercase tracking-widest transition-all cursor-pointer",
                        !isNewCust ? "bg-pnb-gold text-pnb-maroon border-pnb-gold" : "bg-white/5 text-white/40 border-white/10 hover:border-white/30"
                      )}
                    >
                      Existing Customer
                    </button>
                    <button 
                      onClick={() => setIsNewCust(true)}
                      className={cn(
                        "flex-1 py-3 rounded-xl border text-[10px] font-bold uppercase tracking-widest transition-all cursor-pointer",
                        isNewCust ? "bg-pnb-gold text-pnb-maroon border-pnb-gold" : "bg-white/5 text-white/40 border-white/10 hover:border-white/30"
                      )}
                    >
                      New Customer Card
                    </button>
                  </div>

                  {!isNewCust ? (
                    <select 
                      value={selectedCustId}
                      onChange={(e) => setSelectedCustId(e.target.value)}
                      className="w-full bg-black/40 border border-white/10 rounded-xl p-4 text-sm text-white focus:ring-2 focus:ring-pnb-gold/30 outline-none cursor-pointer appearance-none"
                    >
                      <option value="">Select Customer Identity...</option>
                      {customers.map(c => <option key={c.id} value={c.id}>{c.name} ({c.mobile})</option>)}
                    </select>
                  ) : (
                    <div className="space-y-3">
                      <input 
                        value={newName}
                        onChange={(e) => setNewName(e.target.value)}
                        placeholder="Customer Full Name"
                        className="w-full bg-black/40 border border-white/10 rounded-xl p-4 text-sm text-white outline-none focus:ring-2 focus:ring-pnb-gold/30"
                      />
                      <input 
                        value={newMobile}
                        onChange={(e) => setNewMobile(e.target.value)}
                        placeholder="Mobile Number"
                        className="w-full bg-black/40 border border-white/10 rounded-xl p-4 text-sm text-white outline-none focus:ring-2 focus:ring-pnb-gold/30"
                      />
                      <input 
                        value={newAadhaar}
                        onChange={(e) => setNewAadhaar(e.target.value)}
                        placeholder="Aadhaar Number (Optional - AI will fill)"
                        className="w-full bg-black/40 border border-white/10 rounded-xl p-4 text-sm text-white outline-none focus:ring-2 focus:ring-pnb-gold/30 font-mono tracking-wider"
                      />
                    </div>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <label className="flex flex-col items-center justify-center p-8 rounded-2xl border bg-pnb-maroon border-pnb-gold/50 hover:bg-pnb-maroon/80 transition-all cursor-pointer group relative overflow-hidden">
                    <input type="file" accept="image/*" capture="environment" className="hidden" onChange={handleFile} />
                    <Camera className="text-pnb-gold mb-3 group-hover:scale-110 transition-transform" size={40} />
                    <span className="text-[10px] font-bold text-pnb-gold uppercase tracking-widest text-center">Camera Scan</span>
                  </label>
                  <label className="flex flex-col items-center justify-center p-8 rounded-2xl border bg-white/5 border-white/10 hover:bg-white/10 transition-all cursor-pointer group relative overflow-hidden">
                    <input type="file" accept="image/*,application/pdf" className="hidden" onChange={handleFile} />
                    <FileText className="text-white/30 mb-3 group-hover:text-white transition-colors group-hover:scale-110 transition-transform" size={40} />
                    <span className="text-[10px] font-bold text-white/30 group-hover:text-white uppercase tracking-widest text-center">Upload PDF / File</span>
                  </label>
                </div>
                
                <p className="text-[10px] text-white/20 text-center font-bold uppercase tracking-[0.2em] pt-4 border-t border-white/5">
                   AI-Driven automated recognition enabled
                </p>
              </div>
            )}
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

const ServiceWorkflow = ({ onHomeClick, serviceType }: { onHomeClick: () => void, serviceType: string }) => {
  const steps = [
    { id: 'kyc', title: 'KYC Form', description: 'Primary Bank Application Form', mandatory: true },
    { id: 'aadhaar', title: 'Aadhaar Card', description: 'National Identity Document', mandatory: true },
    { id: 'pan', title: 'PAN Card', description: 'Permanent Account Number', mandatory: false },
    { id: 'voter', title: 'Voter ID', description: 'Election Commission Card', mandatory: false },
  ];

  const [currentStep, setCurrentStep] = useState(0);
  const [uploads, setUploads] = useState<Record<string, { file: File; preview: string; processed: boolean; extracted?: ExtractedData }>>({});
  const [isProcessing, setIsProcessing] = useState(false);
  const [isBunching, setIsBunching] = useState(false);
  const [pdfData, setPdfData] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>, stepId: string) => {
    const file = e.target.files?.[0];
    if (file) {
      processFile(file, stepId);
    }
  };

  const processFile = async (file: File, stepId: string) => {
    setIsProcessing(true);
    setError(null);
    
    try {
      const base64 = await fileToBase64(file);
      const extracted = await extractDataFromDocument(base64, file.type);
      
      const reader = new FileReader();
      reader.onloadend = () => {
        setUploads(prev => ({
          ...prev,
          [stepId]: {
            file,
            preview: reader.result as string,
            processed: true,
            extracted
          }
        }));
        setIsProcessing(false);
      };
      reader.readAsDataURL(file);
    } catch (err) {
      console.error("AI Extraction failed:", err);
      // Fallback
      const reader = new FileReader();
      reader.onloadend = () => {
        setUploads(prev => ({
          ...prev,
          [stepId]: {
            file,
            preview: reader.result as string,
            processed: true
          }
        }));
        setIsProcessing(false);
      };
      reader.readAsDataURL(file);
    }
  };

  const enhanceImage = (imgSrc: string): Promise<string> => {
    return new Promise((resolve) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = img.width;
        canvas.height = img.height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.filter = 'contrast(1.3) brightness(1.05) saturate(0)'; // Scanner effect
          ctx.drawImage(img, 0, 0);
          resolve(canvas.toDataURL('image/jpeg', 0.85));
        } else {
          resolve(imgSrc);
        }
      };
      img.onerror = () => resolve(imgSrc);
      img.src = imgSrc;
    });
  };

  const generatePDF = async () => {
    // Validation
    if (!uploads['kyc'] || !uploads['aadhaar']) {
      setError("Wait a second, Rup! We need the mandatory photos before I can bunch these into a PDF.");
      return;
    }

    setIsBunching(true);
    setError(null);

    try {
      const doc = new jsPDF('p', 'mm', 'a4');
      const pageWidth = doc.internal.pageSize.getWidth();
      const pageHeight = doc.internal.pageSize.getHeight();

      const orderedIds = ['kyc', 'aadhaar', 'pan', 'voter'];
      const availableIds = orderedIds.filter(id => uploads[id]);

      for (let i = 0; i < availableIds.length; i++) {
        const id = availableIds[i];
        const enhancedSrc = await enhanceImage(uploads[id].preview);
        
        if (i > 0) doc.addPage();
        
        // Calculate dimensions to fit A4 while maintaining aspect ratio
        const img = new Image();
        await new Promise((res) => {
          img.onload = res;
          img.src = enhancedSrc;
        });

        const imgWidth = img.width;
        const imgHeight = img.height;
        const ratio = imgWidth / imgHeight;
        
        let targetWidth = pageWidth - 20; // 10mm margin
        let targetHeight = targetWidth / ratio;
        
        if (targetHeight > pageHeight - 20) {
          targetHeight = pageHeight - 20;
          targetWidth = targetHeight * ratio;
        }

        const x = (pageWidth - targetWidth) / 2;
        const y = (pageHeight - targetHeight) / 2;

        doc.addImage(enhancedSrc, 'JPEG', x, y, targetWidth, targetHeight);
      }

      const pdfOutput = doc.output('datauristring');
      setPdfData(pdfOutput);
      setIsBunching(false);
    } catch (err) {
      console.error(err);
      setError("Partner, something went wrong while bunching the documents. Let's try again.");
      setIsBunching(false);
    }
  };

  const nextStep = () => {
    const currentStepData = steps[currentStep];
    if (currentStepData.mandatory && !uploads[currentStepData.id]) {
      setError(`Partner, the ${currentStepData.title} is required to proceed with this KYC application.`);
      return;
    }
    if (currentStep < steps.length - 1) {
      setCurrentStep(prev => prev + 1);
      setError(null);
    }
  };

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(prev => prev - 1);
      setError(null);
    }
  };

  const skipStep = () => {
    if (!steps[currentStep].mandatory) {
      setCurrentStep(prev => prev + 1);
      setError(null);
    }
  };

  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = () => {
    if (serviceType === 'Account KYC Submit') {
      generatePDF();
    } else {
      setIsSubmitted(true);
    }
  };

  if (isBunching) {
    return (
      <div className="min-h-screen pnb-gradient flex flex-col items-center justify-center p-6 text-center">
        <motion.div 
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="flex flex-col items-center"
        >
          <div className="relative w-32 h-32 mb-8">
            <RefreshCw className="text-pnb-gold animate-spin absolute inset-0 m-auto" size={80} />
            <FileText className="text-pnb-gold absolute inset-0 m-auto" size={40} />
          </div>
          <h2 className="text-3xl font-display text-white mb-4">Bunching <span className="text-pnb-gold">Documents</span></h2>
          <p className="text-white/60 text-lg max-w-md animate-pulse">
            Hang tight, Partner! I'm organizing those documents into a single PDF for you.
          </p>
        </motion.div>
      </div>
    );
  }

  if (pdfData) {
    return (
      <div className="min-h-screen pnb-gradient flex flex-col items-center justify-center p-6 relative">
        <motion.div 
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="w-full max-w-3xl bg-pnb-dark/80 backdrop-blur-2xl rounded-[2.5rem] border border-pnb-gold/20 shadow-2xl p-12 text-center"
        >
          <div className="w-20 h-20 bg-pnb-gold/10 rounded-2xl flex items-center justify-center text-pnb-gold mx-auto mb-8 border border-pnb-gold/20 shadow-lg shadow-pnb-gold/5">
            <FileText size={40} />
          </div>
          <h2 className="text-4xl font-display text-white mb-4">PDF <span className="text-pnb-gold">Ready!</span></h2>
          <p className="text-white/60 text-lg mb-10 max-w-md mx-auto">
            Partner, your documents have been bunched into a secured, bank-standard PDF.
          </p>
          
          <div className="aspect-[4/3] bg-black/40 rounded-3xl overflow-hidden border border-white/5 mb-10 group relative">
            <iframe 
              src={pdfData} 
              className="w-full h-full border-0 rounded-2xl" 
              title="PDF Preview"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end justify-center p-6 pointer-events-none">
              <p className="text-pnb-gold text-xs font-bold uppercase tracking-widest">Document Preview Enabled</p>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <a 
              href={pdfData} 
              download="PNB_KYC_Application.pdf"
              className="w-full sm:w-auto px-10 py-4 bg-pnb-gold text-pnb-maroon rounded-xl font-bold hover:scale-105 transition-all shadow-xl shadow-pnb-gold/20 cursor-pointer uppercase tracking-widest flex items-center justify-center gap-2"
            >
              <Download size={20} /> Download PDF
            </a>
            <button 
              onClick={onHomeClick}
              className="w-full sm:w-auto px-10 py-4 border border-white/10 text-white hover:bg-white/5 rounded-xl font-bold transition-all cursor-pointer uppercase tracking-widest"
            >
              Return Home
            </button>
          </div>
        </motion.div>
      </div>
    );
  }

  if (isSubmitted) {
    return (
      <div className="min-h-screen pnb-gradient flex flex-col items-center justify-center p-6 relative">
        <motion.div 
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="w-full max-w-2xl bg-pnb-dark/80 backdrop-blur-2xl rounded-[2.5rem] border border-pnb-gold/20 shadow-2xl p-12 text-center"
        >
          <div className="w-20 h-20 bg-green-500/10 rounded-full flex items-center justify-center text-green-500 mx-auto mb-8 border border-green-500/20">
            <CheckCircle2 size={40} />
          </div>
          <h2 className="text-4xl font-display text-white mb-4">Application <span className="text-pnb-gold">Submitted!</span></h2>
          <p className="text-white/60 text-lg mb-10 max-w-md mx-auto">
            Partner, we've successfully collected your documents. Our team will verify them shortly.
          </p>
          
          <div className="bg-white/5 rounded-2xl p-6 border border-white/5 mb-10 text-left">
            <h4 className="text-xs uppercase font-bold tracking-widest text-pnb-gold mb-4">Summary of Documents</h4>
            <div className="space-y-3">
              {steps.map(step => (
                <div key={step.id} className="flex items-center justify-between py-2 border-b border-white/5 last:border-0">
                  <span className="text-sm text-white/70">{step.title}</span>
                  {uploads[step.id] ? (
                    <Badge variant="success">Uploaded</Badge>
                  ) : (
                    <span className="text-xs text-white/20 italic">Not Provided</span>
                  )}
                </div>
              ))}
            </div>
          </div>

          <button 
            onClick={onHomeClick}
            className="px-10 py-4 bg-pnb-gold text-pnb-maroon rounded-xl font-bold hover:scale-105 transition-all shadow-xl shadow-pnb-gold/20 cursor-pointer uppercase tracking-widest"
          >
            Return to Dashboard
          </button>
        </motion.div>
      </div>
    );
  }

  const isComplete = currentStep === steps.length - 1 && 
    (!steps[currentStep].mandatory || uploads[steps[currentStep].id]);

  const progress = ((currentStep + (uploads[steps[currentStep].id] ? 1 : 0)) / steps.length) * 100;

  return (
    <div className="min-h-screen pnb-gradient flex flex-col items-center justify-center p-6 relative">
      <div className="absolute top-6 left-6">
        <button 
          onClick={onHomeClick}
          className="flex items-center gap-2 text-white/50 hover:text-white transition-colors cursor-pointer"
        >
          <ArrowRight className="rotate-180" size={16} /> Back to Portal
        </button>
      </div>

      <div className="w-full max-w-2xl bg-pnb-dark/80 backdrop-blur-2xl rounded-[2.5rem] border border-pnb-gold/20 shadow-2xl overflow-hidden">
        {/* Progress Bar */}
        <div className="h-2 bg-white/5 w-full">
          <motion.div 
            initial={{ width: 0 }}
            animate={{ width: `${progress}%` }}
            className="h-full bg-pnb-gold shadow-[0_0_10px_rgba(212,175,55,0.5)]"
          />
        </div>

        <div className="p-8 md:p-12">
          {/* Header */}
          <div className="flex items-center justify-between mb-10">
            <div>
              <p className="text-pnb-gold text-[10px] font-bold uppercase tracking-[0.3em] mb-1">Step {currentStep + 1} of {steps.length}</p>
              <h2 className="text-3xl font-display text-white">{steps[currentStep].title}</h2>
              <p className="text-white/40 text-sm mt-1">{steps[currentStep].description}</p>
            </div>
            <div className="w-14 h-14 bg-pnb-gold/10 rounded-2xl flex items-center justify-center text-pnb-gold border border-pnb-gold/20">
              <Scan size={28} />
            </div>
          </div>

          {error && (
            <motion.div 
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="mb-8 p-4 bg-red-500/10 border border-red-500/20 rounded-xl flex items-start gap-3 text-red-500"
            >
              <AlertCircle size={18} className="shrink-0 mt-0.5" />
              <p className="text-sm font-medium">{error}</p>
            </motion.div>
          )}

          {/* Upload Area */}
          <div className="relative aspect-video bg-black/40 rounded-3xl border-2 border-dashed border-white/5 flex flex-col items-center justify-center p-8 transition-all overflow-hidden group">
            {isProcessing ? (
              <div className="flex flex-col items-center gap-4">
                <RefreshCw className="text-pnb-gold animate-spin" size={40} />
                <p className="text-pnb-gold text-sm font-bold uppercase tracking-widest animate-pulse">Processing...</p>
              </div>
            ) : uploads[steps[currentStep].id] ? (
              <div className="w-full h-full flex flex-col items-center justify-center space-y-4">
                <div className="relative group/thumb">
                  {uploads[steps[currentStep].id].file.type === 'application/pdf' ? (
                    <div className="w-40 h-40 bg-pnb-maroon rounded-xl border border-pnb-gold/20 flex flex-col items-center justify-center gap-3">
                      <FileText size={48} className="text-pnb-gold" />
                      <span className="text-[10px] text-pnb-gold font-bold uppercase tracking-widest">Document PDF</span>
                    </div>
                  ) : (
                    <img 
                      src={uploads[steps[currentStep].id].preview} 
                      alt="Preview" 
                      className="max-h-40 rounded-xl border border-white/10 shadow-2xl" 
                    />
                  )}
                  <div className="absolute -top-2 -right-2 w-6 h-6 bg-green-500 rounded-full flex items-center justify-center text-white shadow-lg">
                    <Check size={14} />
                  </div>
                </div>
                <p className="text-white font-bold flex items-center gap-2">
                  <CheckCircle2 className="text-green-500" size={16} /> 
                  Document Captured
                </p>
                <button 
                  onClick={() => setUploads(prev => {
                    const next = { ...prev };
                    delete next[steps[currentStep].id];
                    return next;
                  })}
                  className="text-white/30 hover:text-white text-xs font-bold uppercase tracking-widest cursor-pointer"
                >
                  Remove & Re-scan
                </button>
              </div>
            ) : (
              <>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 w-full">
                  <label className="flex flex-col items-center justify-center p-8 rounded-2xl bg-pnb-maroon border border-pnb-gold/30 hover:bg-pnb-maroon/80 transition-all cursor-pointer group/btn">
                    <input 
                      type="file" 
                      accept="image/*" 
                      capture="environment" 
                      className="hidden" 
                      onChange={(e) => handleFileUpload(e, steps[currentStep].id)}
                    />
                    <Camera size={32} className="text-pnb-gold mb-3 group-hover/btn:scale-110 transition-transform" />
                    <span className="text-pnb-gold font-bold text-sm uppercase tracking-tighter">Scan Now</span>
                  </label>
                  
                  <label className="flex flex-col items-center justify-center p-8 rounded-2xl border border-white/10 hover:bg-white/5 transition-all cursor-pointer group/btn">
                    <input 
                      type="file" 
                      accept="image/*,application/pdf" 
                      className="hidden" 
                      onChange={(e) => handleFileUpload(e, steps[currentStep].id)}
                    />
                    <FileText size={32} className="text-white/30 mb-3 group-hover/btn:scale-110 transition-transform group-hover/btn:text-white" />
                    <span className="text-white/40 font-bold text-sm uppercase tracking-tighter group-hover/btn:text-white">Upload PDF / File</span>
                  </label>
                </div>
                <p className="mt-8 text-white/20 text-[10px] font-bold uppercase tracking-[0.2em] text-center">
                  Partner, choose your preferred method to proceed
                </p>
              </>
            )}
          </div>

          {/* Navigation */}
          <div className="mt-10 flex items-center justify-between gap-4">
            <button 
              onClick={prevStep}
              className={cn(
                "px-8 py-3 rounded-xl font-bold text-sm transition-all flex items-center gap-2",
                currentStep === 0 ? "opacity-0 pointer-events-none" : "text-white/40 hover:text-white cursor-pointer"
              )}
            >
              <ArrowRight className="rotate-180" size={16} /> Back
            </button>

            <div className="flex gap-4">
              {!steps[currentStep].mandatory && !uploads[steps[currentStep].id] && (
                <button 
                  onClick={skipStep}
                  className="px-8 py-3 border border-white/10 text-white/40 hover:text-white hover:border-white/20 rounded-xl font-bold text-sm transition-all cursor-pointer"
                >
                  Skip Step
                </button>
              )}
              
              <button 
                onClick={currentStep === steps.length - 1 ? handleSubmit : nextStep}
                disabled={steps[currentStep].mandatory && !uploads[steps[currentStep].id]}
                className={cn(
                  "px-10 py-3 rounded-xl font-bold text-sm transition-all flex items-center gap-2 shadow-xl",
                  steps[currentStep].mandatory && !uploads[steps[currentStep].id] 
                    ? "bg-white/5 text-white/20 cursor-not-allowed" 
                    : "bg-pnb-gold text-pnb-maroon hover:scale-105 shadow-pnb-gold/20 cursor-pointer"
                )}
              >
                {currentStep === steps.length - 1 
                  ? (serviceType === 'Account KYC Submit' ? 'Bunch Documents' : 'Submit Application') 
                  : 'Next Step'} <ChevronRight size={18} />
              </button>
            </div>
          </div>
        </div>
      </div>
      
      {/* Footer Info */}
      <div className="mt-8 flex items-center gap-4 px-6 py-2 bg-white/5 rounded-full border border-white/5 backdrop-blur-md">
        <Shield size={14} className="text-pnb-gold" />
        <p className="text-[10px] font-bold text-white/30 uppercase tracking-[0.2em]">Partner, your data is encrypted during this secure session</p>
      </div>
    </div>
  );
};

const HomePage = ({ onLoginClick, onServiceClick, onScanClick, isAdminLoggedIn }: { onLoginClick: () => void, onServiceClick: (title: string) => void, onScanClick: (title: string) => void, isAdminLoggedIn?: boolean }) => {
  const [showLocation, setShowLocation] = useState(false);

  return (
    <div className="min-h-screen pnb-gradient overflow-hidden relative">
      {/* Background Orbs */}
      <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] bg-pnb-maroon-accent/30 rounded-full blur-[120px]" />
      <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-pnb-gold/5 rounded-full blur-[120px]" />

      {/* Navbar */}
      <nav className="relative z-10 flex items-center justify-between px-6 py-4 max-w-7xl mx-auto border-b border-white/10">
        <div 
          onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
          className="flex items-center gap-2 cursor-pointer group"
        >
          <div className="w-10 h-10 bg-pnb-maroon rounded-lg flex items-center justify-center border border-pnb-gold/30 group-hover:border-pnb-gold transition-all">
            <Shield className="text-pnb-gold w-6 h-6" />
          </div>
          <span className="text-white font-bold text-xl tracking-tight">PNB <span className="text-pnb-gold">CSP Assistant</span></span>
        </div>
        <div className="hidden md:flex items-center gap-8 text-white/70 text-sm font-medium">
          <button 
            onClick={() => setShowLocation(true)}
            className="hover:text-pnb-gold transition-colors cursor-pointer"
          >
            Location
          </button>
          <a 
            href="https://mail.google.com/mail/?view=cm&fs=1&to=jakirhossainobc786@gmail.com" 
            target="_blank"
            rel="noopener noreferrer"
            className="hover:text-pnb-gold transition-colors"
          >
            Support
          </a>
        </div>
        <button 
          onClick={onLoginClick}
          className="px-6 py-2 bg-pnb-maroon text-pnb-gold border border-pnb-gold/50 rounded-full text-sm font-semibold hover:bg-pnb-maroon/80 transition-all flex items-center gap-2"
        >
          {isAdminLoggedIn ? (
            <>
              <Shield size={16} /> Admin Panel
            </>
          ) : (
            <>
              <Lock size={16} /> Admin Login
            </>
          )}
        </button>
      </nav>

      <AnimatePresence>
        {showLocation && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-6 bg-black/80 backdrop-blur-sm"
          >
            <motion.div 
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              className="bg-pnb-dark border border-pnb-gold/20 rounded-[2.5rem] w-full max-w-2xl overflow-hidden relative shadow-2xl"
            >
              <button 
                onClick={() => setShowLocation(false)}
                className="absolute top-6 right-6 w-10 h-10 rounded-full bg-white/5 flex items-center justify-center text-white/50 hover:text-white transition-colors cursor-pointer"
              >
                <X size={20} />
              </button>

              <div className="p-8 md:p-12">
                <div className="flex items-center gap-4 mb-8">
                  <div className="w-14 h-14 bg-pnb-gold/10 rounded-2xl flex items-center justify-center text-pnb-gold shadow-lg shadow-pnb-gold/10">
                    <Building2 size={28} />
                  </div>
                  <div>
                    <h2 className="text-2xl font-bold text-white uppercase tracking-tight">BC Office <span className="text-pnb-gold italic">Schedule</span></h2>
                    <p className="text-white/40 text-[10px] font-bold uppercase tracking-[0.3em]">PNB Customer Service Point Operations</p>
                  </div>
                </div>

                <div className="space-y-4">
                  {[
                    { time: '08:00 AM - 10:30 AM', location: 'UPAR FATEPUR' },
                    { time: '11:00 AM - 02:00 PM', location: 'MPUR' },
                    { time: '02:30 PM - 05:30 PM', location: 'UPAR FATEPUR' },
                    { time: '06:00 PM - 08:00 PM', location: 'BALUTUNGI' }
                  ].map((slot, i) => (
                    <motion.div 
                      key={i}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: i * 0.1 }}
                      className="p-5 bg-white/5 rounded-2xl border border-white/5 hover:border-pnb-gold/20 hover:bg-white/10 transition-all flex flex-col md:flex-row md:items-center justify-between gap-4"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-pnb-gold/10 rounded-xl flex items-center justify-center text-pnb-gold">
                          <Clock size={18} />
                        </div>
                        <span className="text-white text-lg font-bold tracking-tight">{slot.time}</span>
                      </div>
                      <div className="flex items-center gap-2 px-4 py-2 bg-pnb-maroon/20 border border-pnb-gold/30 rounded-full">
                        <Building2 size={14} className="text-pnb-gold" />
                        <span className="text-pnb-gold font-bold text-xs uppercase tracking-widest">{slot.location}</span>
                      </div>
                    </motion.div>
                  ))}
                </div>

                <div className="mt-10 p-6 bg-pnb-gold rounded-2xl text-center">
                  <p className="text-pnb-maroon font-bold text-sm mb-1 uppercase tracking-[0.1em]">Working Days: Monday to Saturday</p>
                  <p className="text-pnb-maroon/60 text-[10px] font-bold uppercase tracking-widest">Sunday: Hub Synchronisation (Closed)</p>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Hero Section */}
      <main className="relative z-10 max-w-7xl mx-auto px-6 pt-12 pb-24">
        <div className="text-center mb-12">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="inline-flex items-center gap-2 px-3 py-1 bg-pnb-gold/10 border border-pnb-gold/20 rounded-full text-pnb-gold text-xs font-bold uppercase tracking-widest mb-4"
          >
            <Shield size={12} /> Digital Service Point
          </motion.div>
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-4xl md:text-6xl font-display text-white mb-4 leading-tight"
          >
            Form Filling <span className="text-pnb-gold italic">& AI Scan</span>
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-white/60 text-sm max-w-xl mx-auto mb-10"
          >
            Select a service below to begin form filling or use AI Scan for instant data extraction.
          </motion.p>

          <div className="flex items-center justify-center gap-4 mb-16 underline-offset-8">
            <div className="h-[1px] w-12 bg-pnb-gold/20" />
            <span className="text-[10px] font-bold text-pnb-gold/60 uppercase tracking-[0.4em]">Section 01: Application Forms</span>
            <div className="h-[1px] w-12 bg-pnb-gold/20" />
          </div>

          {/* Service Buttons - Now the Focus */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-6xl mx-auto relative">
            {/* Visual connector */}
            <div className="hidden lg:block absolute -top-8 left-1/2 -translate-x-1/2 w-px h-8 bg-gradient-to-b from-transparent to-pnb-gold/20" />
            
            {[
              { title: 'KYC Update', icon: <RefreshCw size={32} />, desc: 'Biometric update & validation' },
              { title: 'Account KYC Submit', icon: <FileCheck size={32} />, desc: 'E-KYC for new accounts' },
              { title: 'Info Update', icon: <UserRound size={32} />, desc: 'Phone, Address or Photo update' },
            ].map((service, idx) => (
              <motion.div
                key={service.title}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 + idx * 0.1 }}
                whileHover={{ y: -5 }}
                className="group relative bg-[#1c1c1c] border border-white/10 rounded-[2rem] p-8 text-center hover:border-pnb-gold/30 hover:bg-[#252525] transition-all"
              >
                <div className="w-16 h-16 bg-pnb-gold/5 rounded-2xl flex items-center justify-center text-pnb-gold mx-auto mb-6 group-hover:bg-pnb-gold/10 transition-colors">
                  {service.icon}
                </div>
                <h3 className="text-xl font-bold text-white mb-2">{service.title}</h3>
                <p className="text-white/40 text-xs mb-8">{service.desc}</p>
                
                <div className="flex flex-col gap-3">

                  <button 
                    onClick={() => onScanClick(service.title)}
                    className="w-full py-4 bg-white/5 text-pnb-gold border border-pnb-gold/20 font-bold uppercase text-[10px] tracking-[0.2em] rounded-2xl hover:bg-pnb-gold hover:text-pnb-maroon transition-all cursor-pointer flex items-center justify-center gap-2 group/btn"
                  >
                    <Scan size={14} className="group-hover/btn:scale-110 transition-transform" /> AI Fast Scan
                  </button>

                  {service.title === 'Info Update' && (
                    <a 
                      href="https://drive.google.com/file/d/11n0TQiKyqHHPWMiilxADEMjxAlSCRRww/view?usp=sharing"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full py-3 mt-1 bg-white/5 text-white/40 border border-dashed border-white/10 font-bold uppercase text-[9px] tracking-widest rounded-xl hover:border-pnb-gold/40 hover:text-pnb-gold transition-all cursor-pointer flex items-center justify-center gap-2"
                    >
                      <Download size={12} /> Download Form
                    </a>
                  )}

                  {service.title === 'KYC Update' && (
                    <a 
                      href="https://pnb.bank.in/downloadprocess.aspx?fid=ifCApieVe6+c/uwezO5VJg=="
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full py-2 text-pnb-gold/60 hover:text-pnb-gold font-bold text-[10px] uppercase tracking-widest flex items-center justify-center gap-2 transition-colors"
                    >
                      <Download size={12} />
                      Form Download
                    </a>
                  )}
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Badges */}
        <div className="flex flex-wrap justify-center gap-8">
          {[
            { label: 'Secure & Safe', icon: <Shield size={18} /> },
            { label: 'Real-time Updates', icon: <Clock size={18} /> },
            { label: 'Quick Processing', icon: <ArrowRight size={18} /> }
          ].map((item) => (
            <div key={item.label} className="flex items-center gap-2 text-white/50 text-sm">
              <div className="text-pnb-gold">{item.icon}</div>
              {item.label}
            </div>
          ))}
        </div>
      </main>
    </div>
  );
};

// --- Page: Admin Login ---
const AdminLogin = ({ onBack, onSuccess }: { onBack: () => void, onSuccess: () => void }) => {
  const [error, setError] = useState<React.ReactNode | null>(null);
  const [loading, setLoading] = useState(false);

  const handleGoogleLogin = async () => {
    setLoading(true);
    setError(null);
    try {
      const result = await signInWithPopup(auth, googleProvider, browserPopupRedirectResolver);
      const user = result.user;
      
      if (!user.email || !ALLOWED_ADMINS.some(admin => admin.toLowerCase() === user.email?.toLowerCase())) {
        const attemptedEmail = user.email || 'Unknown';
        await signOut(auth);
        setError(`Access Denied: ${attemptedEmail} is not authorized as an administrator. Please use a registered admin account.`);
      } else {
        onSuccess();
      }
    } catch (err: any) {
      console.error("Auth Error:", err);
      if (err.code === 'auth/popup-blocked') {
        setError('Login popup was blocked by your browser. Please allow popups for this site or use the "Open in New Tab" button.');
      } else if (err.code === 'auth/invalid-credential' || err.message?.includes('malformed response')) {
        setError(
          <>
            <p className="mb-2">Configuration Mismatch or Iframe Restriction detected.</p>
            <p className="text-sm opacity-80 mb-4">Try opening the app in a <strong>new tab</strong> using the button at the top right of the preview if login fails in this window.</p>
            <a 
              href={window.location.href} 
              target="_blank" 
              rel="noopener noreferrer"
              className="inline-block px-4 py-2 bg-white/10 hover:bg-white/20 rounded-lg text-xs transition-all border border-white/10"
            >
              Open in New Tab & Retry
            </a>
          </>
        );
      } else {
        setError(`Authentication failed: ${err.message || 'Please try again.'}`);
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen pnb-gradient flex items-center justify-center p-6">
      <div className="absolute top-4 left-6">
        <button onClick={onBack} className="text-white/50 hover:text-white flex items-center gap-2 text-sm transition-colors cursor-pointer">
          <ArrowRight className="rotate-180" size={16} /> Back to Portal
        </button>
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md bg-pnb-maroon-dark/80 backdrop-blur-xl p-8 rounded-[2rem] border border-pnb-gold/30 shadow-2xl shadow-black/50"
      >
        <div className="text-center mb-8">
          <div 
            onClick={onBack}
            className="w-16 h-16 bg-pnb-maroon rounded-2xl flex items-center justify-center border border-pnb-gold/30 mx-auto mb-4 cursor-pointer hover:border-pnb-gold transition-colors group"
          >
            <Shield className="text-pnb-gold w-8 h-8 group-hover:scale-110 transition-transform" />
          </div>
          <h2 className="text-2xl font-bold text-white tracking-tight">PNB <span className="text-pnb-gold">CSP Assistant</span></h2>
          <p className="text-white/40 text-[10px] font-bold uppercase tracking-[0.2em] mt-2">Secure Administrative Gate</p>
        </div>

        {error && (
          <div className="bg-red-500/10 border border-red-500/20 text-red-500 text-xs p-4 rounded-xl mb-6 text-center">
            {error}
          </div>
        )}

        <div className="space-y-6">
          <div className="p-6 bg-white/5 rounded-2xl border border-white/5 text-center">
            <p className="text-white/60 text-xs mb-4">Secure authentication using official PNB authorized Google accounts</p>
            <button 
              disabled={loading}
              onClick={handleGoogleLogin}
              className="w-full py-4 bg-white text-pnb-maroon flex items-center justify-center gap-3 font-bold rounded-xl hover:bg-white/90 transition-all disabled:opacity-50 cursor-pointer shadow-lg shadow-black/20"
            >
              {loading ? (
                <RefreshCw size={20} className="animate-spin" />
              ) : (
                <>
                  <LogIn size={20} />
                  Continue with Google
                </>
              )}
            </button>
          </div>
          
          <div className="flex items-center gap-4 py-2">
            <div className="flex-1 h-[1px] bg-white/5" />
            <span className="text-[10px] font-bold text-white/20 uppercase tracking-widest whitespace-nowrap">Security Policy Applied</span>
            <div className="flex-1 h-[1px] bg-white/5" />
          </div>

          <div className="text-[10px] text-white/30 text-center leading-relaxed">
            Unauthorized access attempts are logged and reported to the system security department. 
            Contact IT support if you cannot access your node.
          </div>
        </div>

        <div className="mt-8 flex items-center justify-center gap-4 py-4 border-t border-white/5">
          <Shield size={16} className="text-pnb-gold/40" />
          <p className="text-white/20 text-[10px] uppercase tracking-widest">End-to-End Encrypted Tunnel</p>
        </div>
      </motion.div>
    </div>
  );
};

// --- Page: Admin Dashboard Layout ---
const AdminDashboard = ({ 
  onLogout, 
  onHomeClick,
  applications,
  setApplications,
  showToast,
  handleAddDocument,
  handleCreateCustomer,
  isScanVaultOpen,
  setIsScanVaultOpen
}: { 
  onLogout: () => void, 
  onHomeClick: () => void,
  applications: CustomerApplication[],
  setApplications: React.Dispatch<React.SetStateAction<CustomerApplication[]>>,
  showToast: (message: string, type?: 'success' | 'error') => void,
  handleAddDocument: (customerId: string, file: File, extracted?: ExtractedData) => Promise<void>,
  handleCreateCustomer: (name: string, mobile: string, aadhaar: string, extra?: Partial<ExtractedData>, photoUrl?: string) => Promise<string>,
  isScanVaultOpen: boolean,
  setIsScanVaultOpen: (open: boolean) => void
}) => {
  const [activeTab, setActiveTab] = useState<'Applications' | 'CustList' | 'Search' | 'Location'>('Applications');
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [selectedCustomer, setSelectedCustomer] = useState<CustomerApplication | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<ApplicationStatus | 'All'>('All');
  const [isNoteModalOpen, setIsNoteModalOpen] = useState<{ appId: string; nextStatus: ApplicationStatus } | null>(null);
  const [rejectionNote, setRejectionNote] = useState('');

  const menuItems = [
    { id: 'Applications', icon: <FileText size={20} /> },
    { id: 'CustList', icon: <Users size={20} /> },
    { id: 'Location', icon: <Building2 size={20} /> },
    { id: 'Search', icon: <Search size={20} /> },
  ];

  const downloadCustomerPDF = (app: CustomerApplication) => {
    const doc = new jsPDF() as any;
    
    // Header
    doc.setFillColor(116, 17, 34); // PNB Maroon
    doc.rect(0, 0, 210, 40, 'F');
    
    doc.setTextColor(255, 255, 255);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(22);
    doc.text('PUNJAB NATIONAL BANK', 105, 20, { align: 'center' });
    doc.setFontSize(14);
    doc.text('CUSTOMER PROFILE RECORD', 105, 30, { align: 'center' });
    
    // Body
    doc.setTextColor(0, 0, 0);
    doc.setFontSize(18);
    doc.text('Customer Information', 20, 60);
    
    // Line
    doc.setDrawColor(190, 150, 80); // PNB Gold
    doc.setLineWidth(1);
    doc.line(20, 65, 190, 65);
    
    doc.setFontSize(12);
    doc.setFont('helvetica', 'normal');
    
    const data = [
      ['Customer ID', app.id],
      ['Full Name', app.name],
      ['Aadhaar Number', app.aadhaar],
      ['PAN Number', app.pan || 'N/A'],
      ['Mobile', app.mobile],
      ['Address', app.address || 'N/A'],
      ['Status', app.status],
      ['Created Date', app.date],
    ];
    
    autoTable(doc, {
      startY: 75,
      head: [['Field', 'Value']],
      body: data,
      theme: 'grid',
      headStyles: { fillColor: [116, 17, 34], textColor: [255, 255, 255] },
      alternateRowStyles: { fillColor: [245, 245, 245] },
    });
    
    // Documents section
    const finalY = (doc as any).lastAutoTable.finalY || 150;
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.text('Digital Assets & Documents', 20, finalY + 20);
    
    const docsData = app.documents.map((d: any) => [
      d.name,
      d.type,
      d.date,
      d.status
    ]);
    
    autoTable(doc, {
      startY: finalY + 25,
      head: [['Document Name', 'Type', 'Date', 'Status']],
      body: docsData.length > 0 ? docsData : [['No records found', '-', '-', '-']],
      theme: 'striped',
      headStyles: { fillColor: [190, 150, 80], textColor: [0, 0, 0] },
    });
    
    // Footer
    doc.setFontSize(10);
    doc.setTextColor(150);
    doc.text(`Generated on: ${new Date().toLocaleString()}`, 105, 285, { align: 'center' });
    
    doc.save(`PNB_Customer_${app.name.replace(/\s+/g, '_')}_${app.id.substring(0, 5)}.pdf`);
    showToast('Customer PDF generated successfully', 'success');
  };

  const filteredApps = useMemo(() => {
    return applications
      .filter(app => {
        const matchesSearch = app.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                            app.mobile.includes(searchQuery) ||
                            app.id.toLowerCase().includes(searchQuery.toLowerCase());
        const matchesStatus = statusFilter === 'All' || app.status === statusFilter;
        return matchesSearch && matchesStatus;
      })
      .sort((a, b) => {
        // Sort by updatedAt if available, otherwise fallback to date string
        const dateA = a.updatedAt ? a.updatedAt.toMillis() : new Date(a.date).getTime();
        const dateB = b.updatedAt ? b.updatedAt.toMillis() : new Date(b.date).getTime();
        return dateB - dateA;
      });
  }, [searchQuery, applications, statusFilter]);

  const handleStatusUpdate = async (appId: string, newStatus: ApplicationStatus, note?: string) => {
    const path = `applications/${appId}`;
    try {
      const appRef = doc(db, 'applications', appId);
      const updateData: any = {
        status: newStatus,
        date: new Date().toISOString().split('T')[0], // Update timestamp in readable format
        updatedAt: Timestamp.now()
      };
      
      if (note) updateData.notes = note;

      await updateDoc(appRef, { ...updateData });

      // Update local state for mock
      setApplications(prev => prev.map(app => 
        app.id === appId ? { ...app, ...updateData } : app
      ));

      if (selectedCustomer && selectedCustomer.id === appId) {
        setSelectedCustomer({ ...selectedCustomer, ...updateData });
      }

      if (newStatus === 'Submitted') {
        showToast("Great job, Rup! That's another one sent to the bank.");
      } else {
        showToast(`Status updated to ${newStatus}`);
      }
      
      setIsNoteModalOpen(null);
      setRejectionNote('');
    } catch (error) {
      // For mock UI, if Firebase fails or isn't set up, just update local state
      console.warn("Firebase update failed, updating local state only.", error);
      const updateData: any = {
        status: newStatus,
        date: new Date().toISOString().split('T')[0],
        updatedAt: Timestamp.now()
      };
      if (note) updateData.notes = note;
      
      setApplications(prev => prev.map(app => 
        app.id === appId ? { ...app, ...updateData } : app
      ));
      
      if (selectedCustomer && selectedCustomer.id === appId) {
        setSelectedCustomer({ ...selectedCustomer, ...updateData });
      }

      if (newStatus === 'Submitted') {
        showToast("Great job, Rup! That's another one sent to the bank.");
      } else {
        showToast(`Status updated to ${newStatus}`);
      }
      
      setIsNoteModalOpen(null);
      setRejectionNote('');
    }
  };

  const getStatusColor = (status: ApplicationStatus) => {
    switch (status) {
      case 'Approved': return 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20';
      case 'Rejected': return 'bg-rose-500/10 text-rose-500 border-rose-500/20';
      case 'Submitted':
      case 'Under Review': return 'bg-pnb-gold/10 text-pnb-gold border-pnb-gold/20';
      case 'Processing': return 'bg-blue-500/10 text-blue-400 border-blue-500/20';
      case 'Completed': return 'bg-purple-500/10 text-purple-400 border-purple-500/20';
      default: return 'bg-white/5 text-white/40 border-white/10';
    }
  };

  return (
    <div className="flex h-screen bg-pnb-dark text-white overflow-hidden font-sans">
      {/* Sidebar */}
      <motion.aside 
        animate={{ width: isSidebarOpen ? 260 : 80 }}
        className="bg-pnb-maroon text-white flex flex-col relative z-20 shadow-2xl shrink-0 border-r border-pnb-gold/20"
      >
        <div 
          onClick={onHomeClick}
          className="p-6 flex items-center gap-3 overflow-hidden cursor-pointer hover:bg-white/5 transition-colors group"
          title="Return to Home"
        >
          <div className="min-w-[40px] h-10 bg-gradient-to-br from-pnb-gold to-pnb-gold-dark rounded-full flex items-center justify-center shadow-lg shadow-pnb-gold/20 group-hover:scale-110 transition-transform">
            <Shield className="text-pnb-maroon w-5 h-5" />
          </div>
          {isSidebarOpen && <span className="font-bold text-lg whitespace-nowrap tracking-wide text-pnb-gold">PNB <span className="text-white/90 font-light">CSP Assistant</span></span>}
        </div>

        <nav className="flex-1 px-4 mt-6 space-y-1">
          {menuItems.map((item) => (
            <button 
              key={item.id}
              onClick={() => setActiveTab(item.id as any)}
              className={cn(
                "w-full flex items-center gap-4 p-3 rounded-xl transition-all relative group cursor-pointer text-sm",
                activeTab === item.id ? "bg-pnb-gold/15 text-pnb-gold font-bold border-l-4 border-pnb-gold" : "text-white/50 hover:bg-white/5 hover:text-white"
              )}
            >
              <div className="min-w-[20px]">{item.icon}</div>
              {isSidebarOpen && <span>{item.id}</span>}
            </button>
          ))}
        </nav>

        <div className="p-4 mt-auto border-t border-white/10">
          <button 
            onClick={onLogout}
            className="w-full flex items-center gap-4 p-3 rounded-xl transition-all text-red-300 hover:bg-red-500/10 cursor-pointer"
          >
            <LogOut size={20} />
            {isSidebarOpen && <span>Logout</span>}
          </button>
        </div>

        <button 
          onClick={() => setIsSidebarOpen(!isSidebarOpen)}
          className="absolute -right-3 top-20 w-6 h-6 bg-pnb-gold text-pnb-maroon rounded-full flex items-center justify-center border border-pnb-maroon shadow-md cursor-pointer"
        >
          {isSidebarOpen ? <ChevronRight className="rotate-180" size={14} /> : <ChevronRight size={14} />}
        </button>
      </motion.aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col h-full overflow-hidden bg-pnb-dark relative">
        <div className="absolute inset-0 pnb-gradient opacity-50 pointer-events-none" />
        <header className="h-20 bg-transparent border-b border-white/5 px-8 flex items-center justify-between shrink-0 relative z-10">
          <div>
            <h2 className="text-xl font-bold text-pnb-gold">{activeTab}</h2>
            <p className="text-xs text-white/40 font-medium uppercase tracking-widest">{new Date().toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long' })}</p>
          </div>
          <div className="flex items-center gap-6">
            <div className="hidden lg:flex gap-4">
              <div className="badge flex items-center gap-2 px-3 py-1 bg-white/5 border border-white/10 rounded-full text-[10px] font-bold text-pnb-gold uppercase tracking-wider">
                <span>🛡️</span> SECURE & SAFE
              </div>
              <div className="badge flex items-center gap-2 px-3 py-1 bg-white/5 border border-white/10 rounded-full text-[10px] font-bold text-pnb-gold uppercase tracking-wider">
                <span>⚡</span> QUICK PROCESSING
              </div>
            </div>
            <div className="relative">
              <Search className="absolute left-3 top-2.5 text-white/30" size={16} />
              <input 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search portal..." 
                className="bg-white/5 border border-white/10 rounded-lg py-2 pl-10 pr-4 text-sm text-white focus:ring-2 focus:ring-pnb-gold/20 w-64 outline-none"
              />
            </div>
          </div>
        </header>

        <section className="flex-1 overflow-y-auto p-8">
          <AnimatePresence mode="wait">
            {activeTab === 'Applications' && (
              <motion.div 
                key="applications"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                className="glass-dark rounded-2xl border border-white/5 overflow-hidden shadow-2xl relative z-10"
              >
                <div className="p-6 border-b border-white/5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <h3 className="text-lg font-bold text-pnb-gold">Live Queue</h3>
                    <p className="text-sm text-white/40">Total {filteredApps.length} active synchronization requests</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="relative group/filters">
                      <select 
                        value={statusFilter}
                        onChange={(e) => setStatusFilter(e.target.value as any)}
                        className="bg-white/5 border border-white/10 rounded-full px-4 py-2 text-xs font-bold text-white/70 hover:bg-white/10 transition-colors cursor-pointer appearance-none outline-none pr-8"
                      >
                        <option value="All">All Status</option>
                        <option value="Under Review">Under Review</option>
                        <option value="Processing">Processing</option>
                        <option value="Submitted">Submitted</option>
                        <option value="Approved">Approved</option>
                        <option value="Rejected">Rejected</option>
                      </select>
                      <ChevronDown size={14} className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-white/30" />
                    </div>
                    <button className="px-4 py-2 bg-pnb-gold text-pnb-maroon rounded-full text-xs font-bold hover:scale-105 transition-all cursor-pointer">
                      <Plus size={14} /> New Record
                    </button>
                  </div>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full border-collapse">
                    <thead>
                      <tr className="bg-white/2 text-left border-b border-white/5">
                        <th className="p-4 text-[10px] font-bold uppercase tracking-widest text-white/30">Sync ID</th>
                        <th className="p-4 text-[10px] font-bold uppercase tracking-widest text-white/30">Identity</th>
                        <th className="p-4 text-[10px] font-bold uppercase tracking-widest text-white/30">Class</th>
                        <th className="p-4 text-[10px] font-bold uppercase tracking-widest text-white/30">Phase</th>
                        <th className="p-4 text-[10px] font-bold uppercase tracking-widest text-white/30">Timestamp</th>
                        <th className="p-4 text-[10px] font-bold uppercase tracking-widest text-white/30 text-center">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/2">
                      {filteredApps.map((app) => (
                        <tr key={app.id} className="hover:bg-white/2 transition-colors group">
                          <td className="p-4 font-mono text-xs text-pnb-gold/70">{app.id}</td>
                          <td className="p-4">
                            <button 
                              onClick={() => setSelectedCustomer(app)}
                              className="flex items-center gap-3 hover:text-pnb-gold transition-colors cursor-pointer"
                            >
                              <div className="w-8 h-8 rounded-full bg-pnb-gold/10 flex items-center justify-center text-xs font-bold text-pnb-gold overflow-hidden">
                                {app.photoUrl ? (
                                  <img src={app.photoUrl} alt="" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                                ) : (
                                  app.name.charAt(0)
                                )}
                              </div>
                              <span className="text-sm font-bold text-white/90">{app.name}</span>
                            </button>
                          </td>
                          <td className="p-4"><span className="text-[10px] px-2 py-1 bg-white/5 border border-white/10 rounded text-white/70">{app.type}</span></td>
                          <td className="p-4">
                            <div className="relative inline-block text-left group/status">
                              <button className={cn(
                                "px-2.5 py-1 rounded-full text-[10px] font-bold flex items-center gap-1.5 transition-all border",
                                getStatusColor(app.status)
                              )}>
                                {app.status} <ChevronDown size={10} />
                              </button>
                              <div className="absolute left-0 mt-2 w-40 bg-pnb-maroon-dark border border-white/10 rounded-xl shadow-2xl opacity-0 invisible group-hover/status:opacity-100 group-hover/status:visible transition-all z-30 overflow-hidden">
                                {(['Under Review', 'Processing', 'Submitted', 'Approved', 'Rejected'] as ApplicationStatus[]).map(s => (
                                  <button 
                                    key={s}
                                    onClick={() => {
                                      if (s === 'Rejected') {
                                        setIsNoteModalOpen({ appId: app.id, nextStatus: s });
                                      } else {
                                        handleStatusUpdate(app.id, s);
                                      }
                                    }}
                                    className="w-full px-4 py-2 text-left text-[10px] font-bold text-white/60 hover:bg-white/5 hover:text-pnb-gold transition-colors border-b border-white/5 last:border-0"
                                  >
                                    {s}
                                  </button>
                                ))}
                              </div>
                            </div>
                          </td>
                          <td className="p-4 text-xs font-medium text-white/30">{app.date}</td>
                          <td className="p-4 text-center">
                            <button 
                              onClick={() => setSelectedCustomer(app)}
                              className="w-8 h-8 rounded-full bg-white/5 text-pnb-gold hover:bg-pnb-gold hover:text-pnb-maroon transition-all mx-auto flex items-center justify-center cursor-pointer border border-pnb-gold/20 shadow-lg shadow-pnb-gold/5"
                            >
                              <Eye size={14} />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </motion.div>
            )}

            {activeTab === 'CustList' && (
              <motion.div 
                key="custlist"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="space-y-8 relative z-10"
              >
                <div className="flex items-center justify-between glass-dark p-6 rounded-2xl border border-white/5">
                  <div className="flex-1 max-w-md">
                    <div className="relative">
                      <Search className="absolute left-4 top-3 text-white/30" size={18} />
                      <input 
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        placeholder="Search document vault..." 
                        className="w-full bg-white/5 border border-white/10 rounded-xl py-2.5 pl-12 pr-4 text-sm focus:ring-2 focus:ring-pnb-gold/30 outline-none text-white"
                      />
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <button 
                      onClick={() => setIsScanVaultOpen(true)}
                      className="flex items-center gap-2 px-6 py-2.5 bg-pnb-gold text-pnb-maroon rounded-xl font-bold text-sm shadow-xl shadow-pnb-gold/10 cursor-pointer hover:scale-105 transition-all"
                    >
                      <Scan size={18} /> Scan & Vault
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                  {filteredApps.map((app) => (
                    <motion.div 
                      key={app.id} 
                      whileHover={{ y: -5 }}
                      className="glass-dark p-6 rounded-3xl border border-white/5 flex flex-col relative group overflow-hidden"
                    >
                      <div className="absolute top-0 right-0 p-4 opacity-5 pointer-events-none">
                        <Shield size={80} />
                      </div>
                      <div className="flex items-center gap-4 mb-6">
                        <div className="w-16 h-16 rounded-2xl bg-pnb-gold/10 text-pnb-gold flex items-center justify-center font-display text-2xl font-bold shadow-lg border border-pnb-gold/10 group-hover:bg-pnb-gold group-hover:text-pnb-maroon transition-all overflow-hidden">
                          {app.photoUrl ? (
                            <img src={app.photoUrl} alt="" className="w-full h-full object-cover" />
                          ) : (
                            app.name.charAt(0)
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <h4 className="font-bold text-lg truncate text-white/90">{app.name}</h4>
                          <p className="text-[10px] text-white/30 font-bold uppercase tracking-widest truncate">{app.type}</p>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4 py-4 border-y border-white/5">
                        <div className="col-span-2 pb-3 border-b border-white/5">
                          <p className="text-[10px] text-pnb-gold/50 uppercase font-bold tracking-widest mb-1">Aadhaar Number (Permanent ID)</p>
                          <p className="text-sm font-bold leading-none text-pnb-gold font-mono tracking-[0.1em]">{app.aadhaar}</p>
                        </div>
                        <div>
                          <p className="text-[10px] text-pnb-gold/50 uppercase font-bold tracking-widest mb-1">Mobile Contact</p>
                          <div className="flex items-center gap-2">
                             <p className="text-xs font-bold leading-none text-white/80">{app.mobile}</p>
                             <div className="flex gap-1">
                               <a href={`tel:${app.mobile}`} className="p-1 rounded bg-white/5 text-pnb-gold hover:bg-pnb-gold hover:text-pnb-maroon transition-all">
                                 <Phone size={10} />
                               </a>
                               <a href={`https://wa.me/${app.mobile}`} target="_blank" rel="noreferrer" className="p-1 rounded bg-white/5 text-emerald-500 hover:bg-emerald-500 hover:text-white transition-all">
                                 <MessageCircle size={10} />
                               </a>
                             </div>
                          </div>
                        </div>
                        <div>
                          <p className="text-[10px] text-pnb-gold/50 uppercase font-bold tracking-widest mb-1">Digital Assets</p>
                          <p className="text-xs font-bold leading-none text-white/80 flex items-center gap-1">
                            <FileText size={12} className="text-pnb-gold/60" /> {app.documents.length} Records
                          </p>
                        </div>
                      </div>

                      <div className="mt-6 flex items-center justify-between gap-4">
                         <button 
                          onClick={() => downloadCustomerPDF(app)}
                          className="flex items-center gap-2 px-4 py-2 bg-white/5 border border-white/10 rounded-xl text-[10px] font-bold text-pnb-gold hover:bg-pnb-gold hover:text-pnb-maroon transition-all cursor-pointer group/dl"
                        >
                          <Download size={12} className="group-hover/dl:scale-110 transition-transform" /> PDF
                        </button>
                         <button 
                          onClick={() => setSelectedCustomer(app)}
                          className="flex items-center gap-1 text-xs font-bold text-pnb-gold hover:underline cursor-pointer"
                        >
                          Access Profile <ArrowRight size={14} />
                         </button>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </motion.div>
            )}

            {activeTab === 'Location' && (
              <motion.div 
                key="location"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="max-w-4xl mx-auto space-y-8 relative z-10"
              >
                <div className="text-center mb-12">
                  <h2 className="text-3xl font-bold mb-4 font-display text-pnb-gold tracking-tight lowercase">BC Office <span className="italic">Schedule</span></h2>
                  <p className="text-white/30 text-lg uppercase tracking-[0.3em] font-mono">Operations & Deployment Nodes</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {[
                    { time: '08:00 AM - 10:30 AM', location: 'UPAR FATEPUR', status: 'Active' },
                    { time: '11:00 AM - 02:00 PM', location: 'MPUR', status: 'Active' },
                    { time: '02:30 PM - 05:30 PM', location: 'UPAR FATEPUR', status: 'Active' },
                    { time: '06:00 PM - 08:00 PM', location: 'BALUTUNGI', status: 'Active' }
                  ].map((slot, i) => (
                    <motion.div 
                      key={i}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: i * 0.1 }}
                      className="glass-dark p-6 rounded-3xl border border-white/5 hover:border-pnb-gold/20 transition-all group"
                    >
                      <div className="flex items-center justify-between mb-4">
                        <div className="w-12 h-12 bg-pnb-gold/10 rounded-2xl flex items-center justify-center text-pnb-gold group-hover:bg-pnb-gold group-hover:text-pnb-maroon transition-all">
                          <Clock size={24} />
                        </div>
                        <Badge variant="success">{slot.status}</Badge>
                      </div>
                      <p className="text-pnb-gold/50 text-[10px] font-bold uppercase tracking-[0.2em] mb-1">Time Slot</p>
                      <h3 className="text-xl font-bold text-white mb-4">{slot.time}</h3>
                      <div className="pt-4 border-t border-white/5">
                        <p className="text-white/30 text-[10px] font-bold uppercase tracking-widest mb-1">Service Location</p>
                        <div className="flex items-center gap-2 text-pnb-gold font-bold">
                          <Building2 size={16} />
                          <span>{slot.location}</span>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>

                <div className="p-8 glass-dark rounded-[2rem] border border-white/5 text-center">
                  <p className="text-white/40 text-sm font-medium mb-2 italic">Standard Operating Days: Monday to Saturday</p>
                  <p className="text-[10px] text-pnb-gold/50 font-bold uppercase tracking-widest">Sunday: Operations Halted for Server Sync</p>
                </div>
              </motion.div>
            )}

            {activeTab === 'Search' && (
              <motion.div 
                key="search"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="max-w-4xl mx-auto relative z-10"
              >
                <div className="text-center mb-12">
                  <h2 className="text-3xl font-bold mb-4 font-display text-pnb-gold tracking-tight lowercase">Global Intelligence <span className="italic">Indexing</span></h2>
                  <p className="text-white/30 text-lg uppercase tracking-[0.3em] font-mono">Secure Node / Scan / Verify</p>
                </div>
                <div className="relative mb-12 shadow-2xl">
                  <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-pnb-gold" size={32} />
                  <input 
                    autoFocus
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="E.g. IDENTITY_REF_881"
                    className="w-full bg-pnb-maroon-dark/80 backdrop-blur-xl rounded-[2rem] py-8 pl-20 pr-8 text-2xl border border-pnb-gold/20 focus:outline-none focus:ring-4 focus:ring-pnb-gold/10 text-white placeholder:text-white/10"
                  />
                  {searchQuery && (
                    <button 
                      onClick={() => setSearchQuery('')}
                      className="absolute right-6 top-1/2 -translate-y-1/2 w-10 h-10 bg-white/5 rounded-full flex items-center justify-center text-white/20 hover:text-pnb-gold transition-colors cursor-pointer"
                    >
                      <X size={20} />
                    </button>
                  )}
                </div>

                <div className="space-y-4">
                  {searchQuery && filteredApps.length === 0 && (
                    <div className="text-center py-20 glass-dark rounded-3xl border border-dashed border-white/5">
                      <Search size={48} className="text-white/5 mx-auto mb-4" />
                      <p className="text-white/20 font-bold uppercase tracking-widest">Zero matching nodes found</p>
                    </div>
                  )}
                  {searchQuery && filteredApps.map((app) => (
                    <button 
                      key={app.id} 
                      onClick={() => setSelectedCustomer(app)}
                      className="w-full bg-white/2 backdrop-blur-md p-6 rounded-3xl flex items-center gap-6 border border-white/5 hover:bg-white/5 hover:border-pnb-gold/20 transition-all group text-left cursor-pointer"
                    >
                      <div className="w-14 h-14 rounded-2xl bg-pnb-gold/10 flex items-center justify-center text-pnb-gold font-bold text-xl group-hover:bg-pnb-gold group-hover:text-pnb-maroon transition-all overflow-hidden border border-pnb-gold/10 shadow-lg">
                        {app.photoUrl ? (
                          <img src={app.photoUrl} alt="" className="w-full h-full object-cover" />
                        ) : (
                          app.name.charAt(0)
                        )}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-3">
                          <h4 className="font-bold text-lg leading-none text-white/90">{app.name}</h4>
                          <span className="text-[10px] px-2 py-1 bg-pnb-gold/10 text-pnb-gold font-mono rounded border border-pnb-gold/20">{app.id}</span>
                        </div>
                        <div className="flex gap-4 mt-3">
                           <span className="text-[10px] font-bold text-white/20 uppercase tracking-widest flex items-center gap-1"><CreditCard size={10} className="text-pnb-gold/40" /> {app.pan}</span>
                           <span className="text-[10px] font-bold text-white/20 uppercase tracking-widest flex items-center gap-1"><Shield size={10} className="text-pnb-gold/40" /> {app.aadhaar}</span>
                        </div>
                      </div>
                      <div className="text-right">
                         <Badge variant={app.status === 'Approved' ? 'success' : 'warning'}>{app.status}</Badge>
                         <p className="text-[10px] font-bold text-white/20 uppercase tracking-widest mt-2">{app.date}</p>
                      </div>
                    </button>
                  ))}
                  {!searchQuery && (
                    <div className="text-center py-10 opacity-20">
                       <p className="text-xs uppercase font-bold tracking-[0.5em] text-white">AWAITING SYSTEM INPUT</p>
                    </div>
                  )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </section>
      </main>

      {/* Floating Detail Card Modal */}
      <AnimatePresence>
        {selectedCustomer && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-black/80 backdrop-blur-xl">
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-pnb-maroon-dark/95 w-full max-w-4xl rounded-[2.5rem] overflow-hidden shadow-[0_0_50px_rgba(212,175,55,0.2)] relative border border-pnb-gold/50"
            >
              <button 
                onClick={() => setSelectedCustomer(null)}
                className="absolute top-6 right-6 w-10 h-10 bg-white/5 rounded-full flex items-center justify-center hover:bg-pnb-gold hover:text-pnb-maroon transition-all cursor-pointer z-50 border border-white/10"
              >
                <X size={20} className="text-pnb-gold" />
              </button>

              <div className="flex flex-col md:flex-row h-full max-h-[90vh]">
                <div className="bg-pnb-maroon md:w-80 p-8 text-white relative flex flex-col border-r border-pnb-gold/20">
                  <div className="absolute top-0 right-0 p-4 opacity-5">
                     <Shield size={120} />
                  </div>
                  <div className="relative z-10 flex flex-col flex-1">
                    <div className="w-24 h-24 bg-pnb-gold/20 rounded-3xl flex items-center justify-center text-4xl font-display font-bold border border-pnb-gold/30 mb-6 mx-auto md:mx-0 shadow-lg shadow-pnb-gold/10 overflow-hidden">
                      {selectedCustomer.photoUrl ? (
                        <img src={selectedCustomer.photoUrl} alt="" className="w-full h-full object-cover" />
                      ) : (
                        selectedCustomer.name.charAt(0)
                      )}
                    </div>
                    <h3 className="text-2xl font-bold text-center md:text-left leading-tight text-pnb-gold">{selectedCustomer.name}</h3>
                    <p className="text-white/40 font-bold uppercase text-[10px] tracking-[0.2em] mb-8 text-center md:text-left">{selectedCustomer.id}</p>
                    
                    <div className="space-y-6 mt-auto">
                      <div>
                        <p className="text-[10px] font-bold uppercase tracking-widest text-white/30">Phase Management</p>
                        <div className="relative mt-2">
                           <select 
                            value={selectedCustomer.status}
                            onChange={(e) => {
                              const s = e.target.value as ApplicationStatus;
                              if (s === 'Rejected') {
                                setIsNoteModalOpen({ appId: selectedCustomer.id, nextStatus: s });
                              } else {
                                handleStatusUpdate(selectedCustomer.id, s);
                              }
                            }}
                            className={cn(
                              "w-full bg-black/40 border rounded-xl py-3 px-4 text-sm text-white focus:ring-2 focus:ring-pnb-gold/50 outline-none cursor-pointer appearance-none transition-all",
                              getStatusColor(selectedCustomer.status).split(' ')[2] // Use the border color
                            )}
                          >
                            <option value="Under Review">Under Review</option>
                            <option value="Processing">Processing</option>
                            <option value="Submitted">Submitted</option>
                            <option value="Approved">Approved</option>
                            <option value="Rejected">Rejected</option>
                            <option value="Completed">Completed</option>
                          </select>
                          <ChevronDown size={14} className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-pnb-gold" />
                        </div>
                      </div>

                      {selectedCustomer.notes && (
                        <div className="p-4 bg-white/5 rounded-xl border border-white/10">
                          <p className="text-[10px] font-bold uppercase tracking-widest text-pnb-gold flex items-center gap-1.5 mb-2">
                            <Info size={10} /> Administrative Note
                          </p>
                          <p className="text-xs text-white/60 italic leading-relaxed">"{selectedCustomer.notes}"</p>
                        </div>
                      )}

                      <button 
                        onClick={() => setSelectedCustomer(null)}
                        className="w-full py-4 bg-pnb-gold text-pnb-maroon font-bold rounded-xl text-sm shadow-xl shadow-pnb-gold/20 hover:scale-[1.02] active:scale-[0.98] transition-all cursor-pointer uppercase tracking-widest"
                      >
                        Close Portal
                      </button>
                    </div>
                  </div>
                </div>

                <div className="flex-1 p-10 overflow-y-auto bg-transparent relative">
                  <div className="absolute inset-0 bg-pnb-dark/20 pointer-events-none" />
                  <h4 className="text-xs uppercase font-bold tracking-widest text-pnb-gold mb-6 flex items-center gap-2 border-b border-white/5 pb-2 relative z-10">
                    <UserRound size={14} /> Customer Profile Data & Reminders
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-8 mb-12 relative z-10">
                    {[
                      { label: 'Mobile Number', value: selectedCustomer.mobile, icon: <Phone size={16} /> },
                      { label: 'Email Address', value: selectedCustomer.email, icon: <Mail size={16} /> },
                      { label: 'Aadhaar ID', value: selectedCustomer.aadhaar, icon: <Shield size={16} /> },
                      { label: 'PAN Card Number', value: selectedCustomer.pan, icon: <CreditCard size={16} /> },
                    ].map((item) => (
                      <div key={item.label}>
                        <p className="text-[10px] font-bold text-white/30 uppercase tracking-widest flex items-center gap-1 mb-1">
                          <span className="text-pnb-gold/60">{item.icon}</span> {item.label}
                        </p>
                        <div className="text-sm font-bold text-pnb-gold flex items-center gap-3">
                          {item.value}
                          {item.label === 'Mobile Number' && (
                            <div className="flex gap-2">
                              <a href={`tel:${item.value}`} className="p-1.5 rounded-lg bg-pnb-gold/10 text-pnb-gold hover:bg-pnb-gold hover:text-pnb-maroon transition-all">
                                <Phone size={12} />
                              </a>
                              <a href={`https://wa.me/${item.value}`} target="_blank" rel="noreferrer" className="p-1.5 rounded-lg bg-emerald-500/10 text-emerald-500 hover:bg-emerald-500 hover:text-white transition-all">
                                <MessageCircle size={12} />
                              </a>
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="mb-12 relative z-10">
                    <p className="text-[10px] font-bold text-white/30 uppercase tracking-widest flex items-center gap-2 mb-3">
                      <FileText size={14} className="text-pnb-gold/60" /> Merchant Reminders (Notes)
                    </p>
                    <div className="relative">
                      <textarea 
                        value={selectedCustomer.notes || ''}
                        onChange={(e) => {
                          const note = e.target.value;
                          setApplications(prev => prev.map(app => 
                            app.id === selectedCustomer.id ? { ...app, notes: note } : app
                          ));
                          setSelectedCustomer({ ...selectedCustomer, notes: note });
                        }}
                        placeholder="E.g. Customer needs to bring original PAN card next time..."
                        className="w-full bg-black/40 border border-white/10 rounded-2xl p-6 text-sm text-white/80 outline-none focus:ring-2 focus:ring-pnb-gold/30 h-32 resize-none italic"
                      />
                      <div className="absolute top-4 right-4 animate-pulse opacity-20">
                         <Info size={16} className="text-pnb-gold" />
                      </div>
                    </div>
                  </div>

                  <h4 className="text-xs uppercase font-bold tracking-widest text-pnb-gold mb-6 flex items-center gap-2 border-b border-white/5 pb-2 relative z-10">
                    <FileText size={14} /> Digital Repository & Vault Assets
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 relative z-10">
                    {selectedCustomer.documents.length === 0 ? (
                      <div className="col-span-full py-12 px-4 bg-white/5 rounded-3xl border border-dashed border-white/10 text-center">
                        <Scan size={32} className="text-white/10 mx-auto mb-4" />
                        <p className="text-white/20 font-bold uppercase tracking-widest text-xs">No records present in vault</p>
                      </div>
                    ) : (
                      selectedCustomer.documents.map((doc) => (
                        <motion.div 
                          key={doc.id}
                          whileHover={{ scale: 1.02, y: -5 }}
                          className="group bg-black/40 rounded-2xl border border-white/5 overflow-hidden shadow-xl"
                        >
                          <div className="aspect-square bg-gradient-to-br from-white/5 to-transparent relative flex items-center justify-center p-4">
                            {doc.type.includes('image') ? (
                              <img src={doc.url} alt={doc.name} className="w-full h-full object-cover rounded-lg opacity-60 group-hover:opacity-100 transition-opacity" />
                            ) : (
                              <FileText size={48} className="text-pnb-gold/20" />
                            )}
                            <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-3">
                              <button className="p-2 bg-pnb-gold text-pnb-maroon rounded-full hover:scale-110 transition-transform">
                                <Eye size={16} />
                              </button>
                              <a href={doc.url} download={doc.name} className="p-2 bg-white text-pnb-maroon rounded-full hover:scale-110 transition-transform">
                                <Download size={16} />
                              </a>
                            </div>
                          </div>
                          <div className="p-4 border-t border-white/5">
                            <p className="text-[10px] font-bold text-pnb-gold uppercase tracking-widest mb-1 truncate">{doc.name}</p>
                            <p className="text-[8px] text-white/30 font-bold uppercase tracking-[0.2em]">{doc.date} • {doc.type.split('/')[1]?.toUpperCase() || 'DOC'}</p>
                          </div>
                        </motion.div>
                      ))
                    )}
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Rejection Note Modal */}
      <AnimatePresence>
        {isNoteModalOpen && (
          <div className="fixed inset-0 z-[110] flex items-center justify-center p-6 bg-black/90 backdrop-blur-sm">
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-pnb-dark w-full max-w-md rounded-3xl border border-rose-500/30 p-8 shadow-2xl shadow-rose-500/10"
            >
              <h3 className="text-xl font-bold text-rose-500 flex items-center gap-2 mb-4">
                <AlertCircle size={24} /> Application Rejection
              </h3>
              <p className="text-sm text-white/60 mb-6 font-medium leading-relaxed">
                Partner, please provide a brief note explaining the rejection reason. This will help the customer correct the error.
              </p>
              <textarea 
                autoFocus
                value={rejectionNote}
                onChange={(e) => setRejectionNote(e.target.value)}
                placeholder="E.g. Address proof scan is blurry..."
                className="w-full bg-white/5 border border-white/10 rounded-xl p-4 text-sm text-white outline-none focus:ring-2 focus:ring-rose-500/30 mb-6 h-32 resize-none"
              />
              <div className="flex gap-4">
                <button 
                  onClick={() => setIsNoteModalOpen(null)}
                  className="flex-1 py-3 border border-white/10 rounded-xl font-bold text-white/50 hover:bg-white/5 transition-all text-xs uppercase tracking-widest cursor-pointer"
                >
                  Cancel
                </button>
                <button 
                  onClick={() => handleStatusUpdate(isNoteModalOpen.appId, isNoteModalOpen.nextStatus, rejectionNote)}
                  className="flex-1 py-3 bg-rose-500 text-white rounded-xl font-bold text-xs uppercase tracking-widest shadow-xl shadow-rose-500/20 hover:scale-105 transition-all cursor-pointer"
                >
                  Confirm Rejection
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
};

// --- Main Root ---
export default function App() {
  type View = 'Home' | 'Login' | 'Admin' | 'Service';
  const [currentView, setCurrentView] = useState<View>('Home');
  const [activeService, setActiveService] = useState<string | null>(null);
  const [initializing, setInitializing] = useState(true);

  useEffect(() => {
    let unsubscribeAuth: (() => void) | undefined;
    
    const setupAuth = () => {
      unsubscribeAuth = onAuthStateChanged(auth, (user) => {
        const email = user?.email?.toLowerCase();
        const isAdminUser = !!(user && email && ALLOWED_ADMINS.some(admin => admin.toLowerCase() === email));
        
        // Only redirect away from Admin if the user is no longer an admin
        if (!isAdminUser && currentView === 'Admin') {
          setCurrentView('Home');
        }
        setInitializing(false);
      });
    };

    setupAuth();
    return () => {
      if (unsubscribeAuth) unsubscribeAuth();
    };
  }, [currentView]); // Re-run when view changes to catch redirects

  const [applications, setApplications] = useState<CustomerApplication[]>(MOCK_APPLICATIONS);
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null);
  const [isScanVaultOpen, setIsScanVaultOpen] = useState(false);
  const [scanInitialType, setScanInitialType] = useState<string>('');

  const showToast = (message: string, type: 'success' | 'error' = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3000);
  };

  useEffect(() => {
    const path = 'applications';
    if (!auth.currentUser) return;
    const q = query(collection(db, path), orderBy('date', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const apps = snapshot.docs.map(doc => ({
        ...doc.data(),
        id: doc.id
      })) as CustomerApplication[];
      if (apps.length > 0) {
        setApplications(apps);
      }
    }, (error) => {
      if (auth.currentUser) {
        handleFirestoreError(error, OperationType.LIST, path);
      }
    });
    return () => unsubscribe();
  }, [auth.currentUser]);

  const handleAddDocument = async (customerId: string, file: File, extracted?: ExtractedData) => {
    const newDoc = {
      id: `DOC_${Math.random().toString(36).substr(2, 6).toUpperCase()}`,
      name: file.name,
      type: extracted?.documentType || file.type,
      url: URL.createObjectURL(file), // Local preview
      date: new Date().toISOString().split('T')[0]
    };
    const app = applications.find(a => a.id === customerId);
    if (!app) return;
    const updatedApp = {
      ...app,
      documents: [newDoc, ...app.documents],
      updatedAt: Timestamp.now(),
      name: (extracted?.name && (!app.name || app.name.includes('Extracted'))) ? extracted.name : app.name,
      mobile: (extracted?.mobile && (!app.mobile || app.mobile.includes('Extracted'))) ? extracted.mobile : app.mobile,
      aadhaar: (extracted?.aadhaar && (app.aadhaar.includes('XXXX') || !app.aadhaar)) ? extracted.aadhaar : app.aadhaar,
      pan: (extracted?.pan && (app.pan.includes('XXXX') || !app.pan)) ? extracted.pan : app.pan,
      address: (extracted?.address && (app.address.includes('Updated via Vault') || !app.address)) ? extracted.address : app.address,
    };
    try {
      const appRef = doc(db, 'applications', customerId);
      await updateDoc(appRef, updatedApp);
      if (extracted) {
        showToast(`AI recognised ${extracted.documentType} and updated vault!`);
      } else {
        showToast(`Document saved to ${app.name || 'Vault'}'s vault!`);
      }
    } catch (error) {
      console.error("Failed to add document to Firestore:", error);
      setApplications(prev => prev.map(a => a.id === customerId ? updatedApp : a));
      showToast("Updated locally (Cloud Sync Pending)", "error");
    }
  };

  const handleCreateCustomer = async (name: string, mobile: string, aadhaar: string, extra?: Partial<ExtractedData>, photoUrl?: string) => {
    const newId = `CUST_${Math.random().toString(36).substr(2, 6).toUpperCase()}`;
    const newApp: CustomerApplication = {
      id: newId,
      name: name,
      mobile: mobile,
      email: `${name.toLowerCase().replace(' ', '.')}@pnb.mock`,
      address: extra?.address || 'Updated via Vault Sync',
      aadhaar: aadhaar || extra?.aadhaar || `${Math.floor(1000 + Math.random() * 9000)}-${Math.floor(1000 + Math.random() * 9000)}-${Math.floor(1000 + Math.random() * 9000)}`,
      pan: extra?.pan || `${Math.random().toString(36).substr(2, 5).toUpperCase()}${Math.floor(1000 + Math.random() * 9000)}${Math.random().toString(36).substr(2, 1).toUpperCase()}`,
      photoUrl: photoUrl,
      status: 'Under Review',
      type: extra?.documentType || 'Account KYC Submit',
      date: new Date().toISOString().split('T')[0],
      documents: [],
      updatedAt: Timestamp.now()
    };
    try {
      const appsRef = collection(db, 'applications');
      await addDoc(appsRef, newApp);
      showToast("New Application entry established in Vault");
    } catch (error) {
      console.error("Failed to create customer in Firestore:", error);
      setApplications(prev => [newApp, ...prev]);
      showToast("Created locally (Cloud Sync Pending)", "error");
    }
    return newId;
  };

  const handleLogout = async () => {
    await signOut(auth);
    setCurrentView('Home');
  };

  if (initializing) {
    return (
      <div className="min-h-screen pnb-dark flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <RefreshCw className="text-pnb-gold animate-spin" size={40} />
          <p className="text-pnb-gold text-xs font-bold uppercase tracking-[0.3em]">Synchronizing Secure Nodes...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="antialiased">
      <AnimatePresence mode="wait">
        {currentView === 'Home' && (
          <motion.div 
            key="home"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <HomePage 
              onLoginClick={() => {
                setCurrentView('Login');
              }} 
              onServiceClick={(title) => {
                setActiveService(title);
                setCurrentView('Service');
              }}
              onScanClick={(title) => {
                const user = auth.currentUser;
                if (!user) {
                  showToast("Staff authentication required for AI Sync", "error");
                  setCurrentView('Login');
                  return;
                }
                setScanInitialType(title);
                setIsScanVaultOpen(true);
              }}
              isAdminLoggedIn={!!(auth.currentUser && auth.currentUser.email && ALLOWED_ADMINS.some(admin => admin.toLowerCase() === auth.currentUser?.email?.toLowerCase()))}
            />
          </motion.div>
        )}
        {currentView === 'Service' && (
          <motion.div 
            key="service"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <ServiceWorkflow 
              serviceType={activeService || 'KYC Update'} 
              onHomeClick={() => {
                setCurrentView('Home');
                setActiveService(null);
              }} 
            />
          </motion.div>
        )}
        {currentView === 'Login' && (
          <motion.div 
            key="login"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <AdminLogin onBack={() => setCurrentView('Home')} onSuccess={() => setCurrentView('Admin')} />
          </motion.div>
        )}
        {currentView === 'Admin' && (
          <motion.div 
            key="admin"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <AdminDashboard 
              onLogout={handleLogout} 
              onHomeClick={() => setCurrentView('Home')}
              applications={applications}
              setApplications={setApplications}
              showToast={showToast}
              handleAddDocument={handleAddDocument}
              handleCreateCustomer={handleCreateCustomer}
              isScanVaultOpen={isScanVaultOpen}
              setIsScanVaultOpen={setIsScanVaultOpen}
            />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Global Elements */}
      <ScanVaultModal 
        isOpen={isScanVaultOpen}
        onClose={() => setIsScanVaultOpen(false)}
        customers={applications}
        onAddDocument={handleAddDocument}
        onCreateCustomer={handleCreateCustomer}
        showToast={showToast}
        initialType={scanInitialType}
      />

      <AnimatePresence>
        {toast && (
          <motion.div 
            initial={{ y: 100, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 100, opacity: 0 }}
            className="fixed bottom-10 right-10 z-[300]"
          >
            <div className={cn(
              "px-6 py-4 rounded-2xl border flex items-center gap-3 shadow-2xl backdrop-blur-md",
              toast.type === 'success' ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-500" : "bg-rose-500/10 border-rose-500/20 text-rose-500"
            )}>
              <div className={cn("w-2 h-2 rounded-full", toast.type === 'success' ? "bg-emerald-500" : "bg-rose-500")} />
              <p className="text-sm font-bold uppercase tracking-wider">{toast.message}</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

